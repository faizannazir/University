document.addEventListener("DOMContentLoaded", () => {
    const id = document.getElementById('id');
    const select = document.getElementById('select');
    const label = document.getElementById('label');
    const input = document.getElementById('input');
    const form = document.forms[0];

    select.addEventListener("change", () => {
        console.log(select.value);
        if (select.value == "id") {
            label.setAttribute("for", "id");
            label.innerHTML = "ID";
            input.setAttribute("id", "id");
            input.setAttribute("name", "id");
            input.setAttribute("type", "number");
            input.setAttribute("placeholder", "update Id");
            return
        }

        if (select.value == "name") {
            label.setAttribute("for", "name");
            label.innerHTML = "Name";
            input.setAttribute("id", "name");
            input.setAttribute("name", "name");
            input.setAttribute("type", "text");
            input.setAttribute("placeholder", "update name");
            return
        }

        if (select.value == "email") {
            label.setAttribute("for", "email");
            label.innerHTML = "Email";
            input.setAttribute("id", "email");
            input.setAttribute("name", "email");
            input.setAttribute("type", "email");
            input.setAttribute("placeholder", "update email");
            return
        }

        if (select.value == "dob") {
            label.setAttribute("for", "dob");
            label.innerHTML = "Date Of Birth";
            input.setAttribute("id", "dob");
            input.setAttribute("name", "dob");
            input.setAttribute("type", "date");
            return
        }
        if(select.value=="contact") {
            label.setAttribute("for","contact");
            label.innerHTML="contact";
            input.setAttribute("id","contact");
            input.setAttribute("name","contact");
            input.setAttribute("type","tel");
            input.setAttribute("placeholder", "update contact no");
            return
            }
            if(select.value=="department") {
                label.setAttribute("for","department");
                label.innerHTML="Update department";
                input.setAttribute("type", "hidden");
                const department = document.createElement("select");
                label.insertAdjacentElement("afterend",department)
                department.setAttribute("name","department");
                department.setAttribute("id","department");
                
                var option = document.createElement("option");
                option.setAttribute("value","IT");
                option.innerHTML = "IT Department";
                department.appendChild(option);

                option = document.createElement("option");
                option.setAttribute("value","HR");
                option.innerHTML = "HR Department";
                department.appendChild(option);

                option = document.createElement("option");
                option.setAttribute("value","managment");
                option.innerHTML = "management Department";
                department.appendChild(option);

                return
                }
        else {
            label.innerHTML = "";
            input.setAttribute("type", "hidden");
        }
    });

    form.addEventListener("submit", () => {

    });

});



