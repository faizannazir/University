
document.addEventListener( "DOMContentLoaded",
   ()=>
   {
const filterBtn = document.getElementById("filter-btn");
const startDateInput = document.getElementById("start-date");
const endDateInput = document.getElementById("end-date");


var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1; //January is 0!
var yyyy = today.getFullYear();
// if (dd < 10) {
//   dd = '0' + dd;
// } 
// if (mm < 10) {
//   mm = '0' + mm;
// } 
var maxDate = mm + '/' + dd + '/' + yyyy;
endDateInput.max = maxDate;
startDateInput.max = maxDate;

filterBtn.addEventListener("click", ()=> {
    let startDate = new Date(startDateInput.value);
    startDate = (startDate.getMonth() + 1) + '/' + startDate.getDate()  + '/' + startDate.getFullYear();
    let endDate = new Date(endDateInput.value);
    endDate = (endDate.getMonth() + 1)  + '/' +endDate.getDate() + '/' + endDate.getFullYear();
    console.log(startDate)
    console.log(endDate)
    console.log(maxDate)

    if (startDate > endDate) {
        alert("Start date must be before end date.");
        return;
    }

    if (isNaN(startDateInput) || isNaN(endDateInput)) {
        alert("Invalid date entered.");
        return;
    }
});
   } );